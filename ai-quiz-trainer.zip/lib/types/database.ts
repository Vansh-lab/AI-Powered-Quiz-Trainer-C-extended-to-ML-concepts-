// Database types for AI Quiz Trainer

export interface User {
  id: string
  email: string
  name: string
  handle: string
  avatar_url?: string
  college?: string
  company?: string
  state?: string
  city?: string
  rating: number
  roles: string[]
  preferences: {
    theme: "light" | "dark" | "system"
    dyslexia_friendly: boolean
  }
  created_at: string
  updated_at: string
}

export interface Question {
  id: string
  type: "mcq" | "code_output" | "bug_fix" | "fill_in" | "coding_snippet"
  title: string
  text: string
  language_tags: string[]
  difficulty: number // 1-5
  skills: string[]
  options?: Array<{ id: string; text: string }> // For MCQ questions
  correct_answer: string
  explanation_md: string
  code_snippets: Array<{
    lang: string
    code: string
    title: string
  }>
  constraints: Record<string, any>
  time_limit: number
  author_id?: string
  review_flags: number
  metrics: {
    avg_time: number
    correct_rate: number
    attempt_count: number
  }
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface Attempt {
  id: string
  user_id: string
  question_id: string
  is_correct: boolean
  user_answer: string
  time_taken: number
  difficulty_at_time: number
  user_ability_before?: number
  user_ability_after?: number
  context: Record<string, any>
  created_at: string
}

export interface ReviewCard {
  id: string
  user_id: string
  question_id: string
  easiness: number
  interval_days: number
  repetitions: number
  due_date: string
  last_reviewed?: string
  created_at: string
}

export interface Contest {
  id: string
  title: string
  description?: string
  start_time: string
  end_time: string
  registration_cutoff: string
  rules: {
    negative_marking: number
    full_screen_required: boolean
  }
  question_ids: string[]
  max_participants?: number
  is_active: boolean
  created_at: string
}

export interface ContestResult {
  id: string
  contest_id: string
  user_id: string
  score: number
  total_time: number
  correct_answers: number
  wrong_answers: number
  unanswered: number
  rank_national?: number
  rank_state?: number
  rank_college?: number
  rating_before: number
  rating_after: number
  rating_delta: number
  submitted_at: string
}

export interface UserStats {
  id: string
  user_id: string
  language_tag: string
  total_attempts: number
  correct_attempts: number
  accuracy: number
  avg_time_per_question: number
  mastery_score: number
  current_streak: number
  best_streak: number
  last_activity: string
  updated_at: string
}

export interface Badge {
  id: string
  name: string
  description: string
  icon?: string
  criteria: Record<string, any>
  rarity: "common" | "rare" | "epic" | "legendary"
  created_at: string
}

export interface UserBadge {
  id: string
  user_id: string
  badge_id: string
  earned_at: string
}

// API Response types
export interface ApiResponse<T> {
  data?: T
  error?: string
  success: boolean
}

// Quiz session types
export interface QuizSession {
  id: string
  user_id: string
  questions: Question[]
  current_question_index: number
  start_time: string
  end_time?: string
  mode: "practice" | "contest" | "review"
  context: Record<string, any>
}

// Adaptive learning types
export interface UserAbility {
  user_id: string
  theta: number // IRT ability parameter
  last_updated: string
}

export interface QuestionDifficulty {
  question_id: string
  beta: number // IRT difficulty parameter
  discrimination: number // IRT discrimination parameter
}
