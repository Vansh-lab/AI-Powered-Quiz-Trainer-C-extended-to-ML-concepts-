"use server"

import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { revalidatePath } from "next/cache"

export async function signUp(prevState: any, formData: FormData) {
  if (!formData) {
    return { error: "Form data is missing" }
  }

  const email = formData.get("email")
  const password = formData.get("password")
  const name = formData.get("name")
  const handle = formData.get("handle")

  if (!email || !password || !name || !handle) {
    return { error: "All fields are required" }
  }

  const supabase = createClient()

  try {
    // Check if handle is already taken
    const { data: existingUser } = await supabase
      .from("users")
      .select("handle")
      .eq("handle", handle.toString())
      .single()

    if (existingUser) {
      return { error: "Handle is already taken" }
    }

    // Sign up the user
    const { data, error } = await supabase.auth.signUp({
      email: email.toString(),
      password: password.toString(),
      options: {
        emailRedirectTo:
          process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL ||
          `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/auth/callback`,
        data: {
          name: name.toString(),
          handle: handle.toString(),
        },
      },
    })

    if (error) {
      return { error: error.message }
    }

    // Create user profile in our users table
    if (data.user) {
      const { error: profileError } = await supabase.from("users").insert({
        id: data.user.id,
        email: data.user.email!,
        name: name.toString(),
        handle: handle.toString(),
      })

      if (profileError) {
        console.error("Profile creation error:", profileError)
        // Don't return error here as auth was successful
      }
    }

    return { success: "Check your email to confirm your account and complete registration." }
  } catch (error) {
    console.error("Sign up error:", error)
    return { error: "An unexpected error occurred. Please try again." }
  }
}

export async function signIn(prevState: any, formData: FormData) {
  if (!formData) {
    return { error: "Form data is missing" }
  }

  const email = formData.get("email")
  const password = formData.get("password")

  if (!email || !password) {
    return { error: "Email and password are required" }
  }

  const supabase = createClient()

  try {
    const { error } = await supabase.auth.signInWithPassword({
      email: email.toString(),
      password: password.toString(),
    })

    if (error) {
      return { error: error.message }
    }

    return { success: true }
  } catch (error) {
    console.error("Login error:", error)
    return { error: "An unexpected error occurred. Please try again." }
  }
}

export async function signOut() {
  const supabase = createClient()
  await supabase.auth.signOut()
  revalidatePath("/", "layout")
  redirect("/auth/login")
}

export async function completeOnboarding(prevState: any, formData: FormData) {
  const supabase = createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return { error: "Not authenticated" }
  }

  const college = formData.get("college")
  const state = formData.get("state")
  const city = formData.get("city")
  const selectedTracks = formData.getAll("tracks")

  try {
    // Update user profile
    const { error: updateError } = await supabase
      .from("users")
      .update({
        college: college?.toString(),
        state: state?.toString(),
        city: city?.toString(),
        updated_at: new Date().toISOString(),
      })
      .eq("id", user.id)

    if (updateError) {
      return { error: "Failed to update profile" }
    }

    // Initialize user stats for selected tracks
    const statsInserts = selectedTracks.map((track) => ({
      user_id: user.id,
      language_tag: track.toString(),
    }))

    if (statsInserts.length > 0) {
      await supabase.from("user_stats").insert(statsInserts)
    }

    return { success: true }
  } catch (error) {
    console.error("Onboarding error:", error)
    return { error: "An unexpected error occurred during onboarding." }
  }
}
