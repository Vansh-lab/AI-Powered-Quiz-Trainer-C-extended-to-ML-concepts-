import { createClient } from "@/lib/supabase/server"
import { updateUserProgress } from "./adaptive-engine"

interface SubmitAnswerParams {
  userId: string
  questionId: string
  answer: string
  timeTaken: number
  mode: "practice" | "contest" | "review"
}

interface SubmitAnswerResult {
  isCorrect: boolean
  correctAnswer: string
  explanation: string
}

export async function submitAnswer(params: SubmitAnswerParams): Promise<SubmitAnswerResult> {
  const { userId, questionId, answer, timeTaken, mode } = params
  const supabase = createClient()

  try {
    // Get the question to check the answer
    const { data: question } = await supabase.from("questions").select("*").eq("id", questionId).single()

    if (!question) {
      throw new Error("Question not found")
    }

    // Check if answer is correct
    const isCorrect = checkAnswer(question, answer)

    // Record the attempt
    await supabase.from("attempts").insert({
      user_id: userId,
      question_id: questionId,
      is_correct: isCorrect,
      user_answer: answer,
      time_taken: timeTaken,
      difficulty_at_time: question.difficulty,
      context: { mode },
    })

    // Update user progress and adaptive parameters
    await updateUserProgress(userId, questionId, isCorrect, timeTaken, mode)

    return {
      isCorrect,
      correctAnswer: question.correct_answer,
      explanation: question.explanation_md,
    }
  } catch (error) {
    console.error("Error submitting answer:", error)
    throw error
  }
}

function checkAnswer(question: any, userAnswer: string): boolean {
  const correctAnswer = question.correct_answer.toLowerCase().trim()
  const userAnswerNormalized = userAnswer.toLowerCase().trim()

  switch (question.type) {
    case "mcq":
      return userAnswerNormalized === correctAnswer

    case "code_output":
      return userAnswerNormalized === correctAnswer

    case "fill_in":
      // For fill-in questions, allow multiple correct answers separated by commas
      const correctAnswers = correctAnswer.split(",").map((a) => a.trim())
      return correctAnswers.some((correct) => userAnswerNormalized === correct)

    case "bug_fix":
      // For bug fix, check if the key elements are present
      const keyElements = correctAnswer.split(",").map((a) => a.trim())
      return keyElements.every((element) => userAnswerNormalized.includes(element))

    default:
      return userAnswerNormalized === correctAnswer
  }
}
