import { createClient } from "@/lib/supabase/server"

export async function registerForContest(userId: string, contestId: string) {
  const supabase = createClient()

  try {
    // Check if registration is still open
    const { data: contest } = await supabase.from("contests").select("registration_cutoff").eq("id", contestId).single()

    if (!contest) {
      throw new Error("Contest not found")
    }

    const now = new Date()
    const cutoff = new Date(contest.registration_cutoff)

    if (now > cutoff) {
      throw new Error("Registration period has ended")
    }

    // Check if already registered
    const { data: existing } = await supabase
      .from("contest_registrations")
      .select("id")
      .eq("user_id", userId)
      .eq("contest_id", contestId)
      .single()

    if (existing) {
      throw new Error("Already registered for this contest")
    }

    // Register user
    const { error } = await supabase.from("contest_registrations").insert({
      user_id: userId,
      contest_id: contestId,
    })

    if (error) {
      throw error
    }

    return { success: true }
  } catch (error) {
    console.error("Registration error:", error)
    throw error
  }
}

export async function submitContestAnswer({
  userId,
  contestId,
  questionId,
  answer,
  questionIndex,
}: {
  userId: string
  contestId: string
  questionId: string
  answer: string
  questionIndex: number
}) {
  const supabase = createClient()

  try {
    // Get question details
    const { data: question } = await supabase.from("questions").select("*").eq("id", questionId).single()

    if (!question) {
      throw new Error("Question not found")
    }

    // Check answer
    const isCorrect = checkContestAnswer(question, answer)

    // Record attempt (for contest context)
    await supabase.from("attempts").insert({
      user_id: userId,
      question_id: questionId,
      is_correct: isCorrect,
      user_answer: answer,
      time_taken: 0, // Will be calculated at contest end
      difficulty_at_time: question.difficulty,
      context: {
        mode: "contest",
        contest_id: contestId,
        question_index: questionIndex,
      },
    })

    return {
      correct: isCorrect,
      timeTaken: 0,
    }
  } catch (error) {
    console.error("Error submitting contest answer:", error)
    throw error
  }
}

export async function submitContestResult({
  userId,
  contestId,
  score,
  totalTime,
  correctAnswers,
  wrongAnswers,
  unanswered,
  tabSwitchCount,
}: {
  userId: string
  contestId: string
  score: number
  totalTime: number
  correctAnswers: number
  wrongAnswers: number
  unanswered: number
  tabSwitchCount: number
}) {
  const supabase = createClient()

  try {
    // Get user's current rating
    const { data: user } = await supabase.from("users").select("rating").eq("id", userId).single()

    const currentRating = user?.rating || 1200

    // Calculate new rating (simplified ELO-like system)
    const expectedScore = 0.5 // Simplified, should be based on contest difficulty
    const actualScore = correctAnswers / (correctAnswers + wrongAnswers + unanswered)
    const kFactor = 32
    const ratingDelta = Math.round(kFactor * (actualScore - expectedScore))
    const newRating = Math.max(800, currentRating + ratingDelta)

    // Submit contest result
    const { error } = await supabase.from("contest_results").insert({
      contest_id: contestId,
      user_id: userId,
      score,
      total_time: totalTime,
      correct_answers: correctAnswers,
      wrong_answers: wrongAnswers,
      unanswered,
      rating_before: currentRating,
      rating_after: newRating,
      rating_delta: ratingDelta,
    })

    if (error) {
      throw error
    }

    // Update user rating
    await supabase.from("users").update({ rating: newRating }).eq("id", userId)

    return { success: true, newRating, ratingDelta }
  } catch (error) {
    console.error("Error submitting contest result:", error)
    throw error
  }
}

function checkContestAnswer(question: any, userAnswer: string): boolean {
  const correctAnswer = question.correct_answer.toLowerCase().trim()
  const userAnswerNormalized = userAnswer.toLowerCase().trim()

  switch (question.type) {
    case "mcq":
      return userAnswerNormalized === correctAnswer

    case "code_output":
      return userAnswerNormalized === correctAnswer

    case "fill_in":
      const correctAnswers = correctAnswer.split(",").map((a) => a.trim())
      return correctAnswers.some((correct) => userAnswerNormalized === correct)

    case "bug_fix":
      const keyElements = correctAnswer.split(",").map((a) => a.trim())
      return keyElements.every((element) => userAnswerNormalized.includes(element))

    default:
      return userAnswerNormalized === correctAnswer
  }
}
