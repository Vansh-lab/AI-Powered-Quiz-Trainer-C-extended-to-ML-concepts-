import { createClient } from "@/lib/supabase/server"
import type { Question } from "@/lib/types/database"

// IRT-based adaptive learning parameters
const DEFAULT_THETA = 0 // Default user ability
const DEFAULT_BETA = 0 // Default question difficulty
const DEFAULT_ALPHA = 1 // Default discrimination parameter

interface UserAbility {
  theta: number // User ability parameter
  lastUpdated: string
}

interface QuestionParams {
  beta: number // Difficulty parameter
  alpha: number // Discrimination parameter
}

// Calculate probability of correct answer using IRT 2PL model
function calculateProbability(theta: number, beta: number, alpha = 1): number {
  const exponent = alpha * (theta - beta)
  return 1 / (1 + Math.exp(-exponent))
}

// Update user ability using simple Bayesian update
function updateUserAbility(
  currentTheta: number,
  questionBeta: number,
  questionAlpha: number,
  isCorrect: boolean,
): number {
  const learningRate = 0.1
  const probability = calculateProbability(currentTheta, questionBeta, questionAlpha)

  // Simple gradient-based update
  const gradient = questionAlpha * (isCorrect ? 1 - probability : -probability)
  return currentTheta + learningRate * gradient
}

// Multi-armed bandit for topic selection (epsilon-greedy)
function selectTopicWithBandit(userStats: any[], epsilon = 0.1): string[] {
  if (Math.random() < epsilon) {
    // Exploration: random topic
    const allTopics = ["C", "C++", "Java", "Python", "JavaScript", "Go", "Rust", "DSA/Arrays", "DSA/Trees", "DSA/DP"]
    return [allTopics[Math.floor(Math.random() * allTopics.length)]]
  }

  // Exploitation: select topics with lowest mastery scores
  const sortedStats = userStats
    .filter((stat) => stat.mastery_score < 0.8) // Focus on non-mastered topics
    .sort((a, b) => a.mastery_score - b.mastery_score)

  return sortedStats.slice(0, 3).map((stat) => stat.language_tag)
}

export async function getAdaptiveQuestions(
  userId: string,
  count = 10,
  mode: "practice" | "review" | "contest" = "practice",
): Promise<Question[]> {
  const supabase = createClient()

  try {
    // Get user stats and current ability
    const { data: userStats } = await supabase.from("user_stats").select("*").eq("user_id", userId)

    // Get user's current ability (theta)
    let userTheta = DEFAULT_THETA
    if (userStats && userStats.length > 0) {
      // Calculate average performance as proxy for ability
      const avgAccuracy = userStats.reduce((acc, stat) => acc + stat.accuracy, 0) / userStats.length
      userTheta = Math.log(avgAccuracy / (1 - avgAccuracy + 0.01)) // Logit transform
    }

    let questions: Question[] = []

    if (mode === "review") {
      // For review mode, get due review cards
      const { data: reviewCards } = await supabase
        .from("review_cards")
        .select("*, questions(*)")
        .eq("user_id", userId)
        .lte("due_date", new Date().toISOString().split("T")[0])
        .limit(count)

      questions = reviewCards?.map((card) => card.questions).filter(Boolean) || []
    } else {
      // For practice/contest, use adaptive selection
      const targetTopics =
        userStats && userStats.length > 0 ? selectTopicWithBandit(userStats) : ["C", "Python", "DSA/Arrays"] // Default topics for new users

      // Calculate target difficulty based on user ability
      const targetDifficulty = Math.max(1, Math.min(5, Math.round(3 + userTheta)))

      // Get questions with adaptive difficulty
      const { data: candidateQuestions } = await supabase
        .from("questions")
        .select("*")
        .overlaps("language_tags", targetTopics)
        .gte("difficulty", Math.max(1, targetDifficulty - 1))
        .lte("difficulty", Math.min(5, targetDifficulty + 1))
        .eq("is_active", true)
        .limit(count * 2) // Get more candidates for better selection

      if (candidateQuestions) {
        // Sort by optimal difficulty for user
        const scoredQuestions = candidateQuestions.map((q) => ({
          question: q,
          score: Math.abs(q.difficulty - targetDifficulty) + Math.random() * 0.5, // Add randomness
        }))

        questions = scoredQuestions
          .sort((a, b) => a.score - b.score)
          .slice(0, count)
          .map((item) => item.question)
      }
    }

    return questions
  } catch (error) {
    console.error("Error getting adaptive questions:", error)

    // Fallback: get random questions
    const { data: fallbackQuestions } = await supabase.from("questions").select("*").eq("is_active", true).limit(count)

    return fallbackQuestions || []
  }
}

export async function updateUserProgress(
  userId: string,
  questionId: string,
  isCorrect: boolean,
  timeTaken: number,
  mode: string,
) {
  const supabase = createClient()

  try {
    // Get question details
    const { data: question } = await supabase.from("questions").select("*").eq("id", questionId).single()

    if (!question) return

    // Get current user stats for the question's topics
    const { data: currentStats } = await supabase
      .from("user_stats")
      .select("*")
      .eq("user_id", userId)
      .in("language_tag", question.language_tags)

    // Update or create user stats for each topic
    for (const tag of question.language_tags) {
      const existingStat = currentStats?.find((stat) => stat.language_tag === tag)

      if (existingStat) {
        // Update existing stats
        const newTotalAttempts = existingStat.total_attempts + 1
        const newCorrectAttempts = existingStat.correct_attempts + (isCorrect ? 1 : 0)
        const newAccuracy = newCorrectAttempts / newTotalAttempts
        const newAvgTime =
          (existingStat.avg_time_per_question * existingStat.total_attempts + timeTaken) / newTotalAttempts

        // Update streak
        const newCurrentStreak = isCorrect ? existingStat.current_streak + 1 : 0
        const newBestStreak = Math.max(existingStat.best_streak, newCurrentStreak)

        // Calculate mastery score (combination of accuracy and consistency)
        const masteryScore = Math.min(1, newAccuracy * (1 - Math.exp(-newTotalAttempts / 10)))

        await supabase
          .from("user_stats")
          .update({
            total_attempts: newTotalAttempts,
            correct_attempts: newCorrectAttempts,
            accuracy: newAccuracy,
            avg_time_per_question: newAvgTime,
            mastery_score: masteryScore,
            current_streak: newCurrentStreak,
            best_streak: newBestStreak,
            last_activity: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          })
          .eq("id", existingStat.id)
      } else {
        // Create new stats
        await supabase.from("user_stats").insert({
          user_id: userId,
          language_tag: tag,
          total_attempts: 1,
          correct_attempts: isCorrect ? 1 : 0,
          accuracy: isCorrect ? 1 : 0,
          avg_time_per_question: timeTaken,
          mastery_score: isCorrect ? 0.1 : 0,
          current_streak: isCorrect ? 1 : 0,
          best_streak: isCorrect ? 1 : 0,
          last_activity: new Date().toISOString(),
        })
      }
    }

    // Handle spaced repetition for incorrect answers
    if (!isCorrect && mode === "practice") {
      await scheduleForReview(userId, questionId, supabase)
    }
  } catch (error) {
    console.error("Error updating user progress:", error)
  }
}

// SM-2 Spaced Repetition Algorithm
async function scheduleForReview(userId: string, questionId: string, supabase: any) {
  try {
    const { data: existingCard } = await supabase
      .from("review_cards")
      .select("*")
      .eq("user_id", userId)
      .eq("question_id", questionId)
      .single()

    if (existingCard) {
      // Reset the card for immediate review
      await supabase
        .from("review_cards")
        .update({
          easiness: Math.max(1.3, existingCard.easiness - 0.2),
          interval_days: 1,
          repetitions: 0,
          due_date: new Date().toISOString().split("T")[0],
          last_reviewed: new Date().toISOString(),
        })
        .eq("id", existingCard.id)
    } else {
      // Create new review card
      await supabase.from("review_cards").insert({
        user_id: userId,
        question_id: questionId,
        easiness: 2.5,
        interval_days: 1,
        repetitions: 0,
        due_date: new Date().toISOString().split("T")[0],
      })
    }
  } catch (error) {
    console.error("Error scheduling review:", error)
  }
}
