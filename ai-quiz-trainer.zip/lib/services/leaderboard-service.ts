import { createClient } from "@/lib/supabase/server"

interface LeaderboardParams {
  scope: "national" | "state" | "college"
  range: "daily" | "weekly" | "monthly" | "all-time"
  state?: string
  college?: string
  userId: string
  limit?: number
}

export async function getLeaderboardData({ scope, range, state, college, userId, limit = 100 }: LeaderboardParams) {
  const supabase = createClient()

  try {
    let query = supabase.from("users").select("id, name, handle, avatar_url, rating, state, college, updated_at")

    // Apply scope filters
    switch (scope) {
      case "state":
        if (state) {
          query = query.eq("state", state)
        }
        break
      case "college":
        if (college) {
          query = query.eq("college", college)
        }
        break
      // national has no additional filters
    }

    // Apply time range filters (for now, we'll use all-time data)
    // In a real implementation, you'd filter by contest results or activity within the time range
    if (range !== "all-time") {
      const now = new Date()
      let startDate: Date

      switch (range) {
        case "daily":
          startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000)
          break
        case "weekly":
          startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
          break
        case "monthly":
          startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
          break
        default:
          startDate = new Date(0)
      }

      query = query.gte("updated_at", startDate.toISOString())
    }

    // Get rankings ordered by rating
    const { data: users, error } = await query.order("rating", { ascending: false }).limit(limit)

    if (error) {
      throw error
    }

    // Add rank to each user
    const rankings = users?.map((user, index) => ({
      ...user,
      rank: index + 1,
      rating_change: 0, // This would come from recent contest results
    }))

    // Find user's rank
    const userRankIndex = rankings?.findIndex((user) => user.id === userId)
    const userRank = userRankIndex !== -1 && userRankIndex !== undefined ? userRankIndex + 1 : null

    // Calculate user's percentile
    const totalUsers = rankings?.length || 0
    const percentile = userRank ? ((totalUsers - userRank + 1) / totalUsers) * 100 : null

    // Get statistics
    const stats = {
      totalUsers,
      averageRating: Math.round((rankings?.reduce((sum, user) => sum + user.rating, 0) || 0) / Math.max(totalUsers, 1)),
      topRating: rankings?.[0]?.rating || 0,
    }

    // Get recent rating changes from contest results
    if (range !== "all-time") {
      const { data: recentResults } = await supabase
        .from("contest_results")
        .select("user_id, rating_delta")
        .in("user_id", rankings?.map((u) => u.id) || [])
        .gte("submitted_at", getDateForRange(range))

      // Update rating changes
      if (recentResults && rankings) {
        const ratingChanges = recentResults.reduce(
          (acc, result) => {
            acc[result.user_id] = (acc[result.user_id] || 0) + result.rating_delta
            return acc
          },
          {} as Record<string, number>,
        )

        rankings.forEach((user) => {
          user.rating_change = ratingChanges[user.id] || 0
        })
      }
    }

    return {
      rankings,
      userRank: userRank
        ? {
            rank: userRank,
            percentile,
          }
        : null,
      stats,
    }
  } catch (error) {
    console.error("Error fetching leaderboard data:", error)
    return {
      rankings: [],
      userRank: null,
      stats: {
        totalUsers: 0,
        averageRating: 0,
        topRating: 0,
      },
    }
  }
}

function getDateForRange(range: string): string {
  const now = new Date()
  let startDate: Date

  switch (range) {
    case "daily":
      startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000)
      break
    case "weekly":
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
      break
    case "monthly":
      startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
      break
    default:
      startDate = new Date(0)
  }

  return startDate.toISOString()
}

export async function getUserRankHistory(userId: string, days = 30) {
  const supabase = createClient()

  try {
    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000)

    const { data: contestResults } = await supabase
      .from("contest_results")
      .select("rating_after, submitted_at")
      .eq("user_id", userId)
      .gte("submitted_at", startDate.toISOString())
      .order("submitted_at", { ascending: true })

    return contestResults || []
  } catch (error) {
    console.error("Error fetching user rank history:", error)
    return []
  }
}
