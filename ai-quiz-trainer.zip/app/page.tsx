import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Brain, Zap, Trophy, Users, ArrowRight, Play } from "lucide-react"

export default async function HomePage() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // If user is logged in, redirect to dashboard
  if (user) {
    redirect("/dashboard")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center space-y-8 max-w-4xl mx-auto">
          <div className="flex justify-center">
            <div className="p-4 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full shadow-lg">
              <Brain className="h-12 w-12 text-white" />
            </div>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent leading-tight">
            AI Quiz Trainer
          </h1>

          <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Master programming languages and data structures with our adaptive AI tutor. Join weekly contests and
            compete with developers across India.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link href="/auth/signup">
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-6 text-lg font-medium rounded-xl shadow-lg hover:shadow-xl transition-all"
              >
                <Zap className="mr-2 h-5 w-5" />
                Start Learning Free
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/auth/login">
              <Button
                variant="outline"
                size="lg"
                className="px-8 py-6 text-lg font-medium rounded-xl border-2 border-blue-200 dark:border-blue-800 hover:bg-blue-50 dark:hover:bg-blue-900/20 bg-transparent"
              >
                <Play className="mr-2 h-4 w-4" />
                Sign In
              </Button>
            </Link>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mt-20 max-w-6xl mx-auto">
          <Card className="border-0 shadow-xl bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm hover:shadow-2xl transition-shadow">
            <CardContent className="p-8 text-center space-y-4">
              <div className="p-3 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full w-fit mx-auto">
                <Brain className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100">Adaptive AI Learning</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Our AI tutor adapts to your learning pace, identifies weak areas, and provides personalized question
                recommendations.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-xl bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm hover:shadow-2xl transition-shadow">
            <CardContent className="p-8 text-center space-y-4">
              <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full w-fit mx-auto">
                <Trophy className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100">Weekly Contests</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Compete in pan-India contests every Sunday at 7 PM IST. Climb the national and state leaderboards.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-xl bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm hover:shadow-2xl transition-shadow">
            <CardContent className="p-8 text-center space-y-4">
              <div className="p-3 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full w-fit mx-auto">
                <Users className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100">Community Learning</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Join thousands of students and developers. Track progress, earn badges, and learn together.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Programming Languages */}
        <div className="mt-20 text-center">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-8">Master Multiple Languages & DSA</h2>
          <div className="flex flex-wrap justify-center gap-4">
            {["C", "C++", "Java", "Python", "JavaScript", "Go", "Rust", "DSA"].map((lang) => (
              <div
                key={lang}
                className="px-6 py-3 bg-gradient-to-r from-blue-100 to-indigo-100 dark:from-blue-900/30 dark:to-indigo-900/30 rounded-full text-blue-800 dark:text-blue-200 font-medium border border-blue-200 dark:border-blue-800"
              >
                {lang}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
