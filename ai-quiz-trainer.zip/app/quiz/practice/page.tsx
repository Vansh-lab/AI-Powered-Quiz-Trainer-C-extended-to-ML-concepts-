import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import QuizInterface from "@/components/quiz/quiz-interface"
import { getAdaptiveQuestions } from "@/lib/services/adaptive-engine"

export default async function PracticePage() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user's adaptive questions
  const questions = await getAdaptiveQuestions(user.id, 10, "practice")

  if (!questions || questions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">No Questions Available</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Please complete your onboarding to get personalized questions.
          </p>
        </div>
      </div>
    )
  }

  return <QuizInterface questions={questions} mode="practice" userId={user.id} />
}
