import { createClient } from "@/lib/supabase/server"
import { redirect, notFound } from "next/navigation"
import LiveContestInterface from "@/components/contest/live-contest-interface"

interface LiveContestPageProps {
  params: { id: string }
}

export default async function LiveContestPage({ params }: LiveContestPageProps) {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get contest details
  const { data: contest } = await supabase.from("contests").select("*").eq("id", params.id).single()

  if (!contest) {
    notFound()
  }

  // Check if user is registered
  const { data: registration } = await supabase
    .from("contest_registrations")
    .select("*")
    .eq("contest_id", params.id)
    .eq("user_id", user.id)
    .single()

  if (!registration) {
    redirect(`/contest?error=not_registered`)
  }

  // Check if contest is live
  const now = new Date()
  const startTime = new Date(contest.start_time)
  const endTime = new Date(contest.end_time)

  if (now < startTime) {
    redirect(`/contest?error=not_started`)
  }

  if (now > endTime) {
    redirect(`/contest/${params.id}/results`)
  }

  // Get contest questions
  const { data: questions } = await supabase
    .from("questions")
    .select("*")
    .in("id", contest.question_ids)
    .eq("is_active", true)

  // Check if user has already submitted
  const { data: existingResult } = await supabase
    .from("contest_results")
    .select("*")
    .eq("contest_id", params.id)
    .eq("user_id", user.id)
    .single()

  if (existingResult) {
    redirect(`/contest/${params.id}/results`)
  }

  return <LiveContestInterface contest={contest} questions={questions || []} userId={user.id} />
}
