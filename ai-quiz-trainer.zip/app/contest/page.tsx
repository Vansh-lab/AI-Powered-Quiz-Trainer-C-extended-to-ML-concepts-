import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import ContestListing from "@/components/contest/contest-listing"

export default async function ContestPage() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get upcoming and past contests
  const now = new Date().toISOString()

  const { data: upcomingContests } = await supabase
    .from("contests")
    .select("*")
    .gte("start_time", now)
    .eq("is_active", true)
    .order("start_time", { ascending: true })

  const { data: pastContests } = await supabase
    .from("contests")
    .select("*")
    .lt("end_time", now)
    .eq("is_active", true)
    .order("start_time", { ascending: false })
    .limit(10)

  // Get user's registrations
  const { data: userRegistrations } = await supabase
    .from("contest_registrations")
    .select("contest_id")
    .eq("user_id", user.id)

  const registeredContestIds = userRegistrations?.map((reg) => reg.contest_id) || []

  // Get user's past results
  const { data: userResults } = await supabase
    .from("contest_results")
    .select("*, contests(title)")
    .eq("user_id", user.id)
    .order("submitted_at", { ascending: false })
    .limit(5)

  return (
    <ContestListing
      upcomingContests={upcomingContests || []}
      pastContests={pastContests || []}
      registeredContestIds={registeredContestIds}
      userResults={userResults || []}
      userId={user.id}
    />
  )
}
