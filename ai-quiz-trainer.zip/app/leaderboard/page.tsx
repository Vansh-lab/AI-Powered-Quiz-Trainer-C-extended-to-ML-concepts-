import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import LeaderboardInterface from "@/components/leaderboard/leaderboard-interface"
import { getLeaderboardData } from "@/lib/services/leaderboard-service"

interface LeaderboardPageProps {
  searchParams: {
    scope?: "national" | "state" | "college"
    range?: "daily" | "weekly" | "monthly" | "all-time"
    state?: string
    college?: string
  }
}

export default async function LeaderboardPage({ searchParams }: LeaderboardPageProps) {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile for context
  const { data: userProfile } = await supabase.from("users").select("*").eq("id", user.id).single()

  const scope = searchParams.scope || "national"
  const range = searchParams.range || "all-time"
  const state = searchParams.state || userProfile?.state
  const college = searchParams.college || userProfile?.college

  // Get leaderboard data
  const leaderboardData = await getLeaderboardData({
    scope,
    range,
    state,
    college,
    userId: user.id,
  })

  // Get available states and colleges for filters
  const { data: states } = await supabase.from("users").select("state").not("state", "is", null).order("state")

  const { data: colleges } = await supabase.from("users").select("college").not("college", "is", null).order("college")

  const uniqueStates = [...new Set(states?.map((s) => s.state).filter(Boolean))]
  const uniqueColleges = [...new Set(colleges?.map((c) => c.college).filter(Boolean))]

  return (
    <LeaderboardInterface
      leaderboardData={leaderboardData}
      userProfile={userProfile}
      availableStates={uniqueStates}
      availableColleges={uniqueColleges}
      currentScope={scope}
      currentRange={range}
      currentState={state}
      currentCollege={college}
    />
  )
}
