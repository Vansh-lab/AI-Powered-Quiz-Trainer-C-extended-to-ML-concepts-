import { createClient } from "@/lib/supabase/server"
import { redirect, notFound } from "next/navigation"
import UserProfileView from "@/components/leaderboard/user-profile-view"
import { getUserRankHistory } from "@/lib/services/leaderboard-service"

interface UserProfilePageProps {
  params: { userId: string }
}

export default async function UserProfilePage({ params }: UserProfilePageProps) {
  const supabase = createClient()
  const {
    data: { user: currentUser },
  } = await supabase.auth.getUser()

  if (!currentUser) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: userProfile } = await supabase.from("users").select("*").eq("id", params.userId).single()

  if (!userProfile) {
    notFound()
  }

  // Get user stats
  const { data: userStats } = await supabase.from("user_stats").select("*").eq("user_id", params.userId)

  // Get user badges
  const { data: userBadges } = await supabase
    .from("user_badges")
    .select("*, badges(*)")
    .eq("user_id", params.userId)
    .order("earned_at", { ascending: false })

  // Get recent contest results
  const { data: contestResults } = await supabase
    .from("contest_results")
    .select("*, contests(title)")
    .eq("user_id", params.userId)
    .order("submitted_at", { ascending: false })
    .limit(10)

  // Get rank history
  const rankHistory = await getUserRankHistory(params.userId)

  return (
    <UserProfileView
      userProfile={userProfile}
      userStats={userStats || []}
      userBadges={userBadges || []}
      contestResults={contestResults || []}
      rankHistory={rankHistory}
      isOwnProfile={currentUser.id === params.userId}
    />
  )
}
