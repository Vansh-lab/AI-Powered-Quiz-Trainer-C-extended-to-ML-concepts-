import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardContent from "@/components/dashboard/dashboard-content"

export default async function DashboardPage() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile and stats
  const { data: profile } = await supabase.from("users").select("*").eq("id", user.id).single()

  const { data: userStats } = await supabase.from("user_stats").select("*").eq("user_id", user.id)

  const { data: reviewQueue } = await supabase
    .from("review_cards")
    .select("*, questions(*)")
    .eq("user_id", user.id)
    .lte("due_date", new Date().toISOString().split("T")[0])
    .limit(5)

  return <DashboardContent user={user} profile={profile} userStats={userStats || []} reviewQueue={reviewQueue || []} />
}
