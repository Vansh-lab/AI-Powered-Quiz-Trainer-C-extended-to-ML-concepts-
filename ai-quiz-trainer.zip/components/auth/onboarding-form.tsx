"use client"

import { useActionState } from "react"
import { useFormStatus } from "react-dom"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, Rocket, Code, Database } from "lucide-react"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { completeOnboarding } from "@/lib/actions/auth"

const INDIAN_STATES = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
  "Delhi",
  "Jammu and Kashmir",
  "Ladakh",
]

const PROGRAMMING_TRACKS = [
  { id: "C", name: "C Programming", icon: Code },
  { id: "C++", name: "C++", icon: Code },
  { id: "Java", name: "Java", icon: Code },
  { id: "Python", name: "Python", icon: Code },
  { id: "JavaScript", name: "JavaScript", icon: Code },
  { id: "Go", name: "Go", icon: Code },
  { id: "Rust", name: "Rust", icon: Code },
  { id: "DSA/Arrays", name: "Arrays & Strings", icon: Database },
  { id: "DSA/LinkedLists", name: "Linked Lists", icon: Database },
  { id: "DSA/Trees", name: "Trees & Graphs", icon: Database },
  { id: "DSA/DP", name: "Dynamic Programming", icon: Database },
]

function SubmitButton() {
  const { pending } = useFormStatus()

  return (
    <Button
      type="submit"
      disabled={pending}
      className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium py-6 text-lg rounded-lg h-[60px]"
    >
      {pending ? (
        <>
          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
          Setting up your profile...
        </>
      ) : (
        <>
          <Rocket className="mr-2 h-5 w-5" />
          Start Learning
        </>
      )}
    </Button>
  )
}

export default function OnboardingForm() {
  const router = useRouter()
  const [state, formAction] = useActionState(completeOnboarding, null)
  const [selectedTracks, setSelectedTracks] = useState<string[]>([])
  const [selectedState, setSelectedState] = useState("")

  useEffect(() => {
    if (state?.success) {
      router.push("/dashboard")
    }
  }, [state, router])

  const handleTrackToggle = (trackId: string) => {
    setSelectedTracks((prev) => (prev.includes(trackId) ? prev.filter((id) => id !== trackId) : [...prev, trackId]))
  }

  return (
    <Card className="w-full max-w-2xl shadow-2xl border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
      <CardHeader className="space-y-4 text-center pb-8">
        <div className="flex justify-center">
          <div className="p-3 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full">
            <Rocket className="h-8 w-8 text-white" />
          </div>
        </div>
        <CardTitle className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          Complete Your Profile
        </CardTitle>
        <CardDescription className="text-lg text-gray-600 dark:text-gray-300">
          Help us personalize your learning experience
        </CardDescription>
      </CardHeader>

      <CardContent>
        <form action={formAction} className="space-y-8">
          {state?.error && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 px-4 py-3 rounded-lg text-sm">
              {state.error}
            </div>
          )}

          {/* Location Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Location & Background</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="college" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  College/University (Optional)
                </Label>
                <Input
                  id="college"
                  name="college"
                  type="text"
                  placeholder="Your college name"
                  className="h-12 bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-400"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="state" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  State
                </Label>
                <Select name="state" value={selectedState} onValueChange={setSelectedState}>
                  <SelectTrigger className="h-12 bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600">
                    <SelectValue placeholder="Select your state" />
                  </SelectTrigger>
                  <SelectContent>
                    {INDIAN_STATES.map((state) => (
                      <SelectItem key={state} value={state}>
                        {state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="city" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                City (Optional)
              </Label>
              <Input
                id="city"
                name="city"
                type="text"
                placeholder="Your city"
                className="h-12 bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 focus:border-blue-500 dark:focus:border-blue-400"
              />
            </div>
          </div>

          {/* Learning Tracks */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Choose Your Learning Tracks</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Select the programming languages and topics you want to focus on
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {PROGRAMMING_TRACKS.map((track) => {
                const Icon = track.icon
                return (
                  <div
                    key={track.id}
                    className="flex items-center space-x-3 p-3 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    <Checkbox
                      id={track.id}
                      name="tracks"
                      value={track.id}
                      checked={selectedTracks.includes(track.id)}
                      onCheckedChange={() => handleTrackToggle(track.id)}
                    />
                    <Icon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    <Label
                      htmlFor={track.id}
                      className="text-sm font-medium text-gray-700 dark:text-gray-300 cursor-pointer"
                    >
                      {track.name}
                    </Label>
                  </div>
                )
              })}
            </div>
          </div>

          <SubmitButton />
        </form>
      </CardContent>
    </Card>
  )
}
