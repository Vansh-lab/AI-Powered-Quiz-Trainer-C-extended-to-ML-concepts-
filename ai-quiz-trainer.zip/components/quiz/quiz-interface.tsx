"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Clock, ArrowRight, ArrowLeft, Brain } from "lucide-react"
import type { Question } from "@/lib/types/database"
import QuestionRenderer from "./question-renderer"
import { submitAnswer } from "@/lib/services/quiz-service"
import { motion, AnimatePresence } from "framer-motion"

interface QuizInterfaceProps {
  questions: Question[]
  mode: "practice" | "contest" | "review"
  userId: string
  timeLimit?: number
}

export default function QuizInterface({ questions, mode, userId, timeLimit }: QuizInterfaceProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [timeLeft, setTimeLeft] = useState(timeLimit || 0)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showExplanation, setShowExplanation] = useState(false)
  const [questionStartTime, setQuestionStartTime] = useState(Date.now())
  const [results, setResults] = useState<Record<number, { correct: boolean; timeTaken: number }>>({})

  const currentQuestion = questions[currentIndex]
  const progress = ((currentIndex + 1) / questions.length) * 100

  // Timer effect
  useEffect(() => {
    if (timeLimit && timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1)
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [timeLimit, timeLeft])

  // Reset question start time when question changes
  useEffect(() => {
    setQuestionStartTime(Date.now())
    setShowExplanation(false)
  }, [currentIndex])

  const handleAnswerSubmit = async (answer: string) => {
    if (isSubmitting) return

    setIsSubmitting(true)
    const timeTaken = Math.floor((Date.now() - questionStartTime) / 1000)

    try {
      const result = await submitAnswer({
        userId,
        questionId: currentQuestion.id,
        answer,
        timeTaken,
        mode,
      })

      setResults((prev) => ({
        ...prev,
        [currentIndex]: {
          correct: result.isCorrect,
          timeTaken,
        },
      }))

      setAnswers((prev) => ({ ...prev, [currentIndex]: answer }))
      setShowExplanation(true)
    } catch (error) {
      console.error("Error submitting answer:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1)
    }
  }

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const getDifficultyColor = (difficulty: number) => {
    if (difficulty <= 2) return "bg-green-500"
    if (difficulty <= 3) return "bg-yellow-500"
    if (difficulty <= 4) return "bg-orange-500"
    return "bg-red-500"
  }

  const getDifficultyLabel = (difficulty: number) => {
    if (difficulty <= 2) return "Easy"
    if (difficulty <= 3) return "Medium"
    if (difficulty <= 4) return "Hard"
    return "Expert"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <div className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Brain className="h-6 w-6 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">
                  {mode === "practice" ? "Smart Practice" : mode === "review" ? "Review Session" : "Contest"}
                </h1>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Question {currentIndex + 1} of {questions.length}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {timeLimit && (
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-gray-600" />
                  <span className="font-mono text-lg font-semibold">{formatTime(timeLeft)}</span>
                </div>
              )}

              <div className="flex items-center gap-2">
                <Badge
                  variant="outline"
                  className={`${getDifficultyColor(currentQuestion.difficulty)} text-white border-0`}
                >
                  {getDifficultyLabel(currentQuestion.difficulty)}
                </Badge>
                {currentQuestion.language_tags.map((tag) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-4">
            <Progress value={progress} className="h-2" />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="shadow-xl border-0 bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-xl text-gray-900 dark:text-gray-100">{currentQuestion.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <QuestionRenderer
                    question={currentQuestion}
                    onSubmit={handleAnswerSubmit}
                    isSubmitting={isSubmitting}
                    showExplanation={showExplanation}
                    userAnswer={answers[currentIndex]}
                    result={results[currentIndex]}
                  />
                </CardContent>
              </Card>
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <div className="flex justify-between items-center mt-8">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={currentIndex === 0}
              className="flex items-center gap-2 bg-transparent"
            >
              <ArrowLeft className="h-4 w-4" />
              Previous
            </Button>

            <div className="flex items-center gap-2">
              {questions.map((_, index) => (
                <div
                  key={index}
                  className={`w-3 h-3 rounded-full ${
                    index === currentIndex
                      ? "bg-blue-600"
                      : results[index]
                        ? results[index].correct
                          ? "bg-green-500"
                          : "bg-red-500"
                        : "bg-gray-300 dark:bg-gray-600"
                  }`}
                />
              ))}
            </div>

            <Button
              onClick={handleNext}
              disabled={currentIndex === questions.length - 1}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700"
            >
              Next
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
