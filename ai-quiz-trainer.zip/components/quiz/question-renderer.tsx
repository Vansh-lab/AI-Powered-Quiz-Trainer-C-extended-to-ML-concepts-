"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, Lightbulb, Code, Play, Loader2 } from "lucide-react"
import type { Question } from "@/lib/types/database"
import ReactMarkdown from "react-markdown"
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter"
import { oneDark } from "react-syntax-highlighter/dist/esm/styles/prism"

interface QuestionRendererProps {
  question: Question
  onSubmit: (answer: string) => void
  isSubmitting: boolean
  showExplanation: boolean
  userAnswer?: string
  result?: { correct: boolean; timeTaken: number }
}

export default function QuestionRenderer({
  question,
  onSubmit,
  isSubmitting,
  showExplanation,
  userAnswer,
  result,
}: QuestionRendererProps) {
  const [currentAnswer, setCurrentAnswer] = useState("")

  const handleSubmit = () => {
    if (currentAnswer.trim()) {
      onSubmit(currentAnswer.trim())
    }
  }

  const renderMCQOptions = () => {
    if (!question.options) return null

    return (
      <RadioGroup
        value={currentAnswer}
        onValueChange={setCurrentAnswer}
        disabled={showExplanation}
        className="space-y-3"
      >
        {question.options.map((option) => (
          <div key={option.id} className="flex items-center space-x-3">
            <RadioGroupItem value={option.id} id={option.id} />
            <Label
              htmlFor={option.id}
              className="flex-1 cursor-pointer p-3 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
            >
              {option.text}
            </Label>
          </div>
        ))}
      </RadioGroup>
    )
  }

  const renderCodeInput = () => {
    return (
      <div className="space-y-4">
        <Label htmlFor="code-answer" className="text-sm font-medium">
          Your Answer:
        </Label>
        {question.type === "fill_in" ? (
          <Input
            id="code-answer"
            value={currentAnswer}
            onChange={(e) => setCurrentAnswer(e.target.value)}
            placeholder="Enter your answer..."
            disabled={showExplanation}
            className="font-mono"
          />
        ) : (
          <Textarea
            id="code-answer"
            value={currentAnswer}
            onChange={(e) => setCurrentAnswer(e.target.value)}
            placeholder="Enter your answer..."
            disabled={showExplanation}
            className="font-mono min-h-[120px]"
          />
        )}
      </div>
    )
  }

  const renderCodeSnippets = () => {
    if (!question.code_snippets || question.code_snippets.length === 0) return null

    return (
      <div className="space-y-4">
        {question.code_snippets.map((snippet, index) => (
          <Card key={index} className="bg-gray-900 border-gray-700">
            <CardContent className="p-0">
              <div className="flex items-center justify-between p-3 border-b border-gray-700">
                <div className="flex items-center gap-2">
                  <Code className="h-4 w-4 text-gray-400" />
                  <span className="text-sm font-medium text-gray-300">
                    {snippet.title || `Code Example ${index + 1}`}
                  </span>
                </div>
                <Badge variant="outline" className="text-xs">
                  {snippet.lang}
                </Badge>
              </div>
              <SyntaxHighlighter
                language={snippet.lang}
                style={oneDark}
                customStyle={{
                  margin: 0,
                  borderRadius: 0,
                  background: "transparent",
                }}
              >
                {snippet.code}
              </SyntaxHighlighter>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Question Text */}
      <div className="prose prose-gray dark:prose-invert max-w-none">
        <ReactMarkdown
          components={{
            code({ node, inline, className, children, ...props }) {
              const match = /language-(\w+)/.exec(className || "")
              return !inline && match ? (
                <SyntaxHighlighter style={oneDark} language={match[1]} PreTag="div" {...props}>
                  {String(children).replace(/\n$/, "")}
                </SyntaxHighlighter>
              ) : (
                <code className={className} {...props}>
                  {children}
                </code>
              )
            },
          }}
        >
          {question.text}
        </ReactMarkdown>
      </div>

      {/* Code Snippets */}
      {renderCodeSnippets()}

      {/* Answer Input */}
      {!showExplanation && (
        <div className="space-y-4">
          {question.type === "mcq" ? renderMCQOptions() : renderCodeInput()}

          <Button
            onClick={handleSubmit}
            disabled={!currentAnswer.trim() || isSubmitting}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Submitting...
              </>
            ) : (
              <>
                <Play className="mr-2 h-4 w-4" />
                Submit Answer
              </>
            )}
          </Button>
        </div>
      )}

      {/* Result & Explanation */}
      {showExplanation && result && (
        <div className="space-y-4">
          <Card
            className={`border-2 ${result.correct ? "border-green-500 bg-green-50 dark:bg-green-900/20" : "border-red-500 bg-red-50 dark:bg-red-900/20"}`}
          >
            <CardContent className="p-4">
              <div className="flex items-center gap-3 mb-3">
                {result.correct ? (
                  <CheckCircle className="h-6 w-6 text-green-600" />
                ) : (
                  <XCircle className="h-6 w-6 text-red-600" />
                )}
                <div>
                  <h3
                    className={`font-semibold ${result.correct ? "text-green-800 dark:text-green-200" : "text-red-800 dark:text-red-200"}`}
                  >
                    {result.correct ? "Correct!" : "Incorrect"}
                  </h3>
                  <p
                    className={`text-sm ${result.correct ? "text-green-700 dark:text-green-300" : "text-red-700 dark:text-red-300"}`}
                  >
                    Time taken: {result.timeTaken} seconds
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Your answer:{" "}
                  <span className="font-mono bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">{userAnswer}</span>
                </p>
                {!result.correct && (
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Correct answer:{" "}
                    <span className="font-mono bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                      {question.correct_answer}
                    </span>
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Lightbulb className="h-5 w-5 text-blue-600 mt-1" />
                <div>
                  <h4 className="font-semibold text-blue-800 dark:text-blue-200 mb-2">Explanation</h4>
                  <div className="prose prose-sm prose-blue dark:prose-invert max-w-none">
                    <ReactMarkdown>{question.explanation_md}</ReactMarkdown>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
