"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Brain, Zap, Trophy, Calendar, Target, TrendingUp, Clock, Play, BookOpen, Star } from "lucide-react"
import Link from "next/link"
import type { User } from "@supabase/supabase-js"

interface DashboardProps {
  user: User
  profile: any
  userStats: any[]
  reviewQueue: any[]
}

export default function DashboardContent({ user, profile, userStats, reviewQueue }: DashboardProps) {
  const totalAccuracy =
    userStats.length > 0 ? userStats.reduce((acc, stat) => acc + stat.accuracy, 0) / userStats.length : 0

  const currentStreak = userStats.length > 0 ? Math.max(...userStats.map((stat) => stat.current_streak)) : 0

  const totalQuestions = userStats.reduce((acc, stat) => acc + stat.total_attempts, 0)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <div className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
                Welcome back, {profile?.name || user.email}!
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">Ready to continue your learning journey?</p>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant="secondary" className="text-lg px-4 py-2">
                <Star className="h-4 w-4 mr-2" />
                Rating: {profile?.rating || 1200}
              </Badge>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm font-medium">Overall Accuracy</p>
                  <p className="text-3xl font-bold">{(totalAccuracy * 100).toFixed(1)}%</p>
                </div>
                <Target className="h-8 w-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm font-medium">Current Streak</p>
                  <p className="text-3xl font-bold">{currentStreak}</p>
                </div>
                <Zap className="h-8 w-8 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm font-medium">Questions Solved</p>
                  <p className="text-3xl font-bold">{totalQuestions}</p>
                </div>
                <BookOpen className="h-8 w-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm font-medium">Review Queue</p>
                  <p className="text-3xl font-bold">{reviewQueue.length}</p>
                </div>
                <Clock className="h-8 w-8 text-orange-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="shadow-lg border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="h-5 w-5 text-blue-600" />
                  Quick Start
                </CardTitle>
                <CardDescription>Jump into your personalized learning experience</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Link href="/quiz/practice">
                    <Button className="w-full h-16 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white">
                      <Brain className="h-6 w-6 mr-3" />
                      <div className="text-left">
                        <div className="font-semibold">Smart Practice</div>
                        <div className="text-sm opacity-90">AI-selected questions</div>
                      </div>
                    </Button>
                  </Link>

                  {reviewQueue.length > 0 && (
                    <Link href="/quiz/review">
                      <Button
                        variant="outline"
                        className="w-full h-16 border-2 border-orange-200 hover:bg-orange-50 dark:border-orange-800 dark:hover:bg-orange-900/20 bg-transparent"
                      >
                        <Clock className="h-6 w-6 mr-3 text-orange-600" />
                        <div className="text-left">
                          <div className="font-semibold">Review Queue</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            {reviewQueue.length} questions due
                          </div>
                        </div>
                      </Button>
                    </Link>
                  )}

                  <Link href="/quiz/topics">
                    <Button
                      variant="outline"
                      className="w-full h-16 border-2 border-purple-200 hover:bg-purple-50 dark:border-purple-800 dark:hover:bg-purple-900/20 bg-transparent"
                    >
                      <Target className="h-6 w-6 mr-3 text-purple-600" />
                      <div className="text-left">
                        <div className="font-semibold">Topic Practice</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Focus on specific areas</div>
                      </div>
                    </Button>
                  </Link>

                  <Link href="/contest">
                    <Button
                      variant="outline"
                      className="w-full h-16 border-2 border-green-200 hover:bg-green-50 dark:border-green-800 dark:hover:bg-green-900/20 bg-transparent"
                    >
                      <Trophy className="h-6 w-6 mr-3 text-green-600" />
                      <div className="text-left">
                        <div className="font-semibold">Weekly Contest</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Next: Sunday 7 PM</div>
                      </div>
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Progress by Topic */}
            <Card className="shadow-lg border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                  Your Progress
                </CardTitle>
                <CardDescription>Track your mastery across different topics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {userStats.length > 0 ? (
                    userStats.map((stat) => (
                      <div key={stat.language_tag} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="font-medium text-gray-900 dark:text-gray-100">{stat.language_tag}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-gray-600 dark:text-gray-400">
                              {stat.correct_attempts}/{stat.total_attempts}
                            </span>
                            <Badge
                              variant={
                                stat.accuracy > 0.8 ? "default" : stat.accuracy > 0.6 ? "secondary" : "destructive"
                              }
                            >
                              {(stat.accuracy * 100).toFixed(0)}%
                            </Badge>
                          </div>
                        </div>
                        <Progress value={stat.mastery_score * 100} className="h-2" />
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-600 dark:text-gray-400 text-center py-8">
                      Start practicing to see your progress here!
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Next Contest */}
            <Card className="shadow-lg border-0 bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-800 dark:text-orange-200">
                  <Calendar className="h-5 w-5" />
                  Next Contest
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-3">
                  <div className="text-2xl font-bold text-orange-900 dark:text-orange-100">Sunday 7:00 PM IST</div>
                  <p className="text-sm text-orange-700 dark:text-orange-300">Weekly Programming Contest #42</p>
                  <Link href="/contest">
                    <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">Register Now</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="shadow-lg border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-gray-900 dark:text-gray-100">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-gray-600 dark:text-gray-400">Solved 5 C++ questions</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="text-gray-600 dark:text-gray-400">Completed Arrays topic</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span className="text-gray-600 dark:text-gray-400">Earned "Quick Learner" badge</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
