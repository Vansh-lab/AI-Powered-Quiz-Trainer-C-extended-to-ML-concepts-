"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Trophy,
  Star,
  MapPin,
  GraduationCap,
  Calendar,
  TrendingUp,
  Target,
  Zap,
  Award,
  Clock,
  Code,
} from "lucide-react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface UserProfileViewProps {
  userProfile: any
  userStats: any[]
  userBadges: any[]
  contestResults: any[]
  rankHistory: any[]
  isOwnProfile: boolean
}

export default function UserProfileView({
  userProfile,
  userStats,
  userBadges,
  contestResults,
  rankHistory,
  isOwnProfile,
}: UserProfileViewProps) {
  const totalQuestions = userStats.reduce((acc, stat) => acc + stat.total_attempts, 0)
  const totalCorrect = userStats.reduce((acc, stat) => acc + stat.correct_attempts, 0)
  const overallAccuracy = totalQuestions > 0 ? (totalCorrect / totalQuestions) * 100 : 0
  const bestStreak = Math.max(...userStats.map((stat) => stat.best_streak), 0)

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-IN", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  const getBadgeColor = (rarity: string) => {
    switch (rarity) {
      case "legendary":
        return "bg-gradient-to-r from-purple-500 to-pink-500 text-white"
      case "epic":
        return "bg-gradient-to-r from-blue-500 to-purple-500 text-white"
      case "rare":
        return "bg-gradient-to-r from-green-500 to-blue-500 text-white"
      default:
        return "bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        {/* Profile Header */}
        <Card className="mb-8 shadow-xl border-0 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <Avatar className="h-32 w-32 border-4 border-white/20">
                <AvatarImage src={userProfile.avatar_url || "/placeholder.svg"} />
                <AvatarFallback className="bg-white/20 text-white text-4xl">
                  {userProfile.name?.charAt(0) || "U"}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1 text-center md:text-left">
                <h1 className="text-4xl font-bold mb-2">{userProfile.name}</h1>
                <p className="text-xl text-blue-100 mb-4">@{userProfile.handle}</p>

                <div className="flex flex-wrap justify-center md:justify-start gap-4 mb-4">
                  <div className="flex items-center gap-2">
                    <Star className="h-5 w-5" />
                    <span className="text-lg font-semibold">Rating: {userProfile.rating}</span>
                  </div>
                  {userProfile.state && (
                    <div className="flex items-center gap-2">
                      <MapPin className="h-5 w-5" />
                      <span>{userProfile.state}</span>
                    </div>
                  )}
                  {userProfile.college && (
                    <div className="flex items-center gap-2">
                      <GraduationCap className="h-5 w-5" />
                      <span>{userProfile.college}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    <span>Joined {formatDate(userProfile.created_at)}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{totalQuestions}</div>
                    <div className="text-sm text-blue-200">Questions Solved</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{overallAccuracy.toFixed(1)}%</div>
                    <div className="text-sm text-blue-200">Accuracy</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{bestStreak}</div>
                    <div className="text-sm text-blue-200">Best Streak</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{userBadges.length}</div>
                    <div className="text-sm text-blue-200">Badges Earned</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="stats" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4 max-w-2xl mx-auto">
            <TabsTrigger value="stats">Statistics</TabsTrigger>
            <TabsTrigger value="badges">Badges</TabsTrigger>
            <TabsTrigger value="contests">Contests</TabsTrigger>
            <TabsTrigger value="progress">Progress</TabsTrigger>
          </TabsList>

          <TabsContent value="stats" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Topic Performance */}
              <Card className="shadow-lg border-0 bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-blue-600" />
                    Topic Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {userStats.map((stat) => (
                      <div key={stat.language_tag} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="font-medium">{stat.language_tag}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-gray-600 dark:text-gray-400">
                              {stat.correct_attempts}/{stat.total_attempts}
                            </span>
                            <Badge
                              variant={
                                stat.accuracy > 0.8 ? "default" : stat.accuracy > 0.6 ? "secondary" : "destructive"
                              }
                            >
                              {(stat.accuracy * 100).toFixed(0)}%
                            </Badge>
                          </div>
                        </div>
                        <Progress value={stat.mastery_score * 100} className="h-2" />
                        <div className="flex justify-between text-xs text-gray-500">
                          <span>Mastery: {(stat.mastery_score * 100).toFixed(1)}%</span>
                          <span>Avg Time: {stat.avg_time_per_question.toFixed(1)}s</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Rating History Chart */}
              <Card className="shadow-lg border-0 bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-green-600" />
                    Rating History
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {rankHistory.length > 0 ? (
                    <ResponsiveContainer width="100%" height={200}>
                      <LineChart data={rankHistory}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="submitted_at" tickFormatter={(value) => new Date(value).toLocaleDateString()} />
                        <YAxis />
                        <Tooltip
                          labelFormatter={(value) => new Date(value).toLocaleDateString()}
                          formatter={(value) => [value, "Rating"]}
                        />
                        <Line type="monotone" dataKey="rating_after" stroke="#3b82f6" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <TrendingUp className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p>No rating history available</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="badges" className="space-y-6">
            <Card className="shadow-lg border-0 bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-yellow-600" />
                  Achievements ({userBadges.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {userBadges.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {userBadges.map((userBadge) => (
                      <div
                        key={userBadge.id}
                        className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow"
                      >
                        <div className="flex items-center gap-3 mb-2">
                          <div className="text-2xl">{userBadge.badges.icon || "🏆"}</div>
                          <div>
                            <h3 className="font-semibold">{userBadge.badges.name}</h3>
                            <Badge className={getBadgeColor(userBadge.badges.rarity)} size="sm">
                              {userBadge.badges.rarity}
                            </Badge>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{userBadge.badges.description}</p>
                        <p className="text-xs text-gray-500">Earned {formatDate(userBadge.earned_at)}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Award className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No badges earned yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="contests" className="space-y-6">
            <Card className="shadow-lg border-0 bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-purple-600" />
                  Contest History
                </CardTitle>
              </CardHeader>
              <CardContent>
                {contestResults.length > 0 ? (
                  <div className="space-y-3">
                    {contestResults.map((result) => (
                      <div
                        key={result.id}
                        className="flex items-center justify-between p-4 rounded-lg border border-gray-200 dark:border-gray-700"
                      >
                        <div>
                          <h3 className="font-semibold">{result.contests?.title}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{formatDate(result.submitted_at)}</p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold">Score: {result.score}</span>
                            {result.rank_national && <Badge>Rank #{result.rank_national}</Badge>}
                          </div>
                          <div className={`text-sm ${result.rating_delta > 0 ? "text-green-600" : "text-red-600"}`}>
                            Rating: {result.rating_after} ({result.rating_delta > 0 ? "+" : ""}
                            {result.rating_delta})
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Trophy className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No contest participation yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="progress" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="shadow-lg border-0 bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                <CardContent className="p-6 text-center">
                  <Code className="h-8 w-8 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{totalQuestions}</div>
                  <div className="text-sm text-blue-100">Total Questions</div>
                </CardContent>
              </Card>

              <Card className="shadow-lg border-0 bg-gradient-to-r from-green-500 to-green-600 text-white">
                <CardContent className="p-6 text-center">
                  <Target className="h-8 w-8 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{overallAccuracy.toFixed(1)}%</div>
                  <div className="text-sm text-green-100">Overall Accuracy</div>
                </CardContent>
              </Card>

              <Card className="shadow-lg border-0 bg-gradient-to-r from-purple-500 to-purple-600 text-white">
                <CardContent className="p-6 text-center">
                  <Zap className="h-8 w-8 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{bestStreak}</div>
                  <div className="text-sm text-purple-100">Best Streak</div>
                </CardContent>
              </Card>

              <Card className="shadow-lg border-0 bg-gradient-to-r from-orange-500 to-orange-600 text-white">
                <CardContent className="p-6 text-center">
                  <Clock className="h-8 w-8 mx-auto mb-2" />
                  <div className="text-2xl font-bold">
                    {userStats.length > 0
                      ? (
                          userStats.reduce((acc, stat) => acc + stat.avg_time_per_question, 0) / userStats.length
                        ).toFixed(1)
                      : 0}
                    s
                  </div>
                  <div className="text-sm text-orange-100">Avg Time/Question</div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
