"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import {
  Trophy,
  Medal,
  Award,
  Crown,
  Star,
  TrendingUp,
  Users,
  MapPin,
  GraduationCap,
  Search,
  Filter,
} from "lucide-react"
import { useRouter, useSearchParams } from "next/navigation"
import { motion } from "framer-motion"

interface LeaderboardInterfaceProps {
  leaderboardData: any
  userProfile: any
  availableStates: string[]
  availableColleges: string[]
  currentScope: string
  currentRange: string
  currentState?: string
  currentCollege?: string
}

export default function LeaderboardInterface({
  leaderboardData,
  userProfile,
  availableStates,
  availableColleges,
  currentScope,
  currentRange,
  currentState,
  currentCollege,
}: LeaderboardInterfaceProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [searchQuery, setSearchQuery] = useState("")
  const [showFilters, setShowFilters] = useState(false)

  const updateParams = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString())
    if (value) {
      params.set(key, value)
    } else {
      params.delete(key)
    }
    router.push(`/leaderboard?${params.toString()}`)
  }

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="h-6 w-6 text-yellow-500" />
    if (rank === 2) return <Medal className="h-6 w-6 text-gray-400" />
    if (rank === 3) return <Award className="h-6 w-6 text-amber-600" />
    return <span className="text-lg font-bold text-gray-600 dark:text-gray-400">#{rank}</span>
  }

  const getRankBadgeColor = (rank: number) => {
    if (rank === 1) return "bg-gradient-to-r from-yellow-400 to-yellow-600 text-white"
    if (rank === 2) return "bg-gradient-to-r from-gray-300 to-gray-500 text-white"
    if (rank === 3) return "bg-gradient-to-r from-amber-400 to-amber-600 text-white"
    if (rank <= 10) return "bg-gradient-to-r from-blue-500 to-blue-600 text-white"
    if (rank <= 50) return "bg-gradient-to-r from-green-500 to-green-600 text-white"
    return "bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
  }

  const getScopeIcon = (scope: string) => {
    switch (scope) {
      case "national":
        return <Trophy className="h-5 w-5" />
      case "state":
        return <MapPin className="h-5 w-5" />
      case "college":
        return <GraduationCap className="h-5 w-5" />
      default:
        return <Users className="h-5 w-5" />
    }
  }

  const filteredLeaderboard = leaderboardData.rankings?.filter(
    (user: any) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.handle.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <div className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="p-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full">
                <Trophy className="h-10 w-10 text-white" />
              </div>
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Leaderboard
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Compete with the best programmers across India. See where you stand!
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* User's Current Position */}
        {leaderboardData.userRank && (
          <Card className="mb-8 shadow-xl border-0 bg-gradient-to-r from-blue-500 to-purple-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16 border-4 border-white/20">
                    <AvatarImage src={userProfile?.avatar_url || "/placeholder.svg"} />
                    <AvatarFallback className="bg-white/20 text-white text-xl">
                      {userProfile?.name?.charAt(0) || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="text-2xl font-bold">{userProfile?.name}</h3>
                    <p className="text-blue-100">@{userProfile?.handle}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4" />
                        <span>Rating: {userProfile?.rating}</span>
                      </div>
                      {userProfile?.state && (
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          <span>{userProfile.state}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-4xl font-bold">#{leaderboardData.userRank.rank}</div>
                  <p className="text-blue-100">Your Rank</p>
                  {leaderboardData.userRank.percentile && (
                    <p className="text-sm text-blue-200">Top {leaderboardData.userRank.percentile.toFixed(1)}%</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Filters and Controls */}
        <Card className="mb-8 shadow-lg border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
              <div className="flex flex-wrap gap-4 items-center">
                {/* Scope Selection */}
                <Tabs value={currentScope} onValueChange={(value) => updateParams("scope", value)}>
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="national" className="flex items-center gap-2">
                      <Trophy className="h-4 w-4" />
                      National
                    </TabsTrigger>
                    <TabsTrigger value="state" className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      State
                    </TabsTrigger>
                    <TabsTrigger value="college" className="flex items-center gap-2">
                      <GraduationCap className="h-4 w-4" />
                      College
                    </TabsTrigger>
                  </TabsList>
                </Tabs>

                {/* Time Range */}
                <Select value={currentRange} onValueChange={(value) => updateParams("range", value)}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="all-time">All Time</SelectItem>
                  </SelectContent>
                </Select>

                <Button
                  variant="outline"
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center gap-2"
                >
                  <Filter className="h-4 w-4" />
                  Filters
                </Button>
              </div>

              {/* Search */}
              <div className="relative w-full lg:w-80">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search users..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Additional Filters */}
            {showFilters && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {currentScope === "state" && (
                    <Select value={currentState || "all"} onValueChange={(value) => updateParams("state", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select State" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All States</SelectItem>
                        {availableStates.map((state) => (
                          <SelectItem key={state} value={state}>
                            {state}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}

                  {currentScope === "college" && (
                    <Select value={currentCollege || "all"} onValueChange={(value) => updateParams("college", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select College" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Colleges</SelectItem>
                        {availableColleges.map((college) => (
                          <SelectItem key={college} value={college}>
                            {college}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </div>
              </motion.div>
            )}
          </CardContent>
        </Card>

        {/* Leaderboard */}
        <Card className="shadow-xl border-0 bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {getScopeIcon(currentScope)}
              {currentScope.charAt(0).toUpperCase() + currentScope.slice(1)} Rankings
              <Badge variant="secondary" className="ml-2">
                {currentRange.replace("-", " ").toUpperCase()}
              </Badge>
            </CardTitle>
            <CardDescription>
              {currentScope === "state" && currentState && `Showing rankings for ${currentState}`}
              {currentScope === "college" && currentCollege && `Showing rankings for ${currentCollege}`}
              {currentScope === "national" && "Showing national rankings"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {filteredLeaderboard && filteredLeaderboard.length > 0 ? (
              <div className="space-y-3">
                {filteredLeaderboard.map((user: any, index: number) => (
                  <motion.div
                    key={user.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className={`flex items-center justify-between p-4 rounded-lg border transition-all hover:shadow-md ${
                      user.id === userProfile?.id
                        ? "bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800"
                        : "bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800"
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="flex items-center justify-center w-12 h-12">{getRankIcon(user.rank)}</div>

                      <Avatar className="h-12 w-12">
                        <AvatarImage src={user.avatar_url || "/placeholder.svg"} />
                        <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
                          {user.name?.charAt(0) || "U"}
                        </AvatarFallback>
                      </Avatar>

                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-gray-100">{user.name}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">@{user.handle}</p>
                        <div className="flex items-center gap-3 mt-1">
                          {user.state && (
                            <div className="flex items-center gap-1 text-xs text-gray-500">
                              <MapPin className="h-3 w-3" />
                              {user.state}
                            </div>
                          )}
                          {user.college && (
                            <div className="flex items-center gap-1 text-xs text-gray-500">
                              <GraduationCap className="h-3 w-3" />
                              {user.college}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="flex items-center gap-3">
                        <div>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 text-yellow-500" />
                            <span className="font-bold text-lg">{user.rating}</span>
                          </div>
                          {user.rating_change && (
                            <div
                              className={`text-xs flex items-center gap-1 ${
                                user.rating_change > 0 ? "text-green-600" : "text-red-600"
                              }`}
                            >
                              <TrendingUp className="h-3 w-3" />
                              {user.rating_change > 0 ? "+" : ""}
                              {user.rating_change}
                            </div>
                          )}
                        </div>
                        <Badge className={getRankBadgeColor(user.rank)}>#{user.rank}</Badge>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Trophy className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No Rankings Available</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {searchQuery ? "No users found matching your search." : "Be the first to participate and get ranked!"}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Statistics */}
        {leaderboardData.stats && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <Card className="shadow-lg border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">{leaderboardData.stats.totalUsers}</div>
                <p className="text-gray-600 dark:text-gray-400">Total Participants</p>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">{leaderboardData.stats.averageRating}</div>
                <p className="text-gray-600 dark:text-gray-400">Average Rating</p>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">{leaderboardData.stats.topRating}</div>
                <p className="text-gray-600 dark:text-gray-400">Highest Rating</p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
