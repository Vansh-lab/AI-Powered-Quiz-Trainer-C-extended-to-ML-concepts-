"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Clock, AlertTriangle, Trophy, Eye, EyeOff, Send } from "lucide-react"
import type { Question, Contest } from "@/lib/types/database"
import QuestionRenderer from "@/components/quiz/question-renderer"
import { submitContestAnswer, submitContestResult } from "@/lib/services/contest-service"
import { motion, AnimatePresence } from "framer-motion"
import { useRouter } from "next/navigation"

interface LiveContestInterfaceProps {
  contest: Contest
  questions: Question[]
  userId: string
}

export default function LiveContestInterface({ contest, questions, userId }: LiveContestInterfaceProps) {
  const router = useRouter()
  const [currentIndex, setCurrentIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [timeLeft, setTimeLeft] = useState(0)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showSubmitDialog, setShowSubmitDialog] = useState(false)
  const [contestStartTime] = useState(Date.now())
  const [tabSwitchCount, setTabSwitchCount] = useState(0)
  const [isFullScreen, setIsFullScreen] = useState(false)
  const [results, setResults] = useState<Record<number, { correct: boolean; timeTaken: number }>>({})

  const currentQuestion = questions[currentIndex]
  const progress = ((currentIndex + 1) / questions.length) * 100
  const answeredCount = Object.keys(answers).length

  // Initialize timer
  useEffect(() => {
    const endTime = new Date(contest.end_time).getTime()
    const now = Date.now()
    setTimeLeft(Math.max(0, Math.floor((endTime - now) / 1000)))
  }, [contest.end_time])

  // Timer countdown
  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleAutoSubmit()
            return 0
          }
          return prev - 1
        })
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [timeLeft])

  // Full screen enforcement
  useEffect(() => {
    if (contest.rules?.full_screen_required) {
      const enterFullScreen = async () => {
        try {
          await document.documentElement.requestFullscreen()
          setIsFullScreen(true)
        } catch (error) {
          console.error("Failed to enter fullscreen:", error)
        }
      }

      const handleFullScreenChange = () => {
        setIsFullScreen(!!document.fullscreenElement)
      }

      enterFullScreen()
      document.addEventListener("fullscreenchange", handleFullScreenChange)

      return () => {
        document.removeEventListener("fullscreenchange", handleFullScreenChange)
        if (document.fullscreenElement) {
          document.exitFullscreen().catch(console.error)
        }
      }
    }
  }, [contest.rules?.full_screen_required])

  // Tab switch detection
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setTabSwitchCount((prev) => prev + 1)
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange)
  }, [])

  // Prevent copy/paste and right-click
  useEffect(() => {
    const preventCopy = (e: Event) => e.preventDefault()
    const preventRightClick = (e: MouseEvent) => e.preventDefault()

    document.addEventListener("copy", preventCopy)
    document.addEventListener("paste", preventCopy)
    document.addEventListener("contextmenu", preventRightClick)

    return () => {
      document.removeEventListener("copy", preventCopy)
      document.removeEventListener("paste", preventCopy)
      document.removeEventListener("contextmenu", preventRightClick)
    }
  }, [])

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const mins = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    return `${hours}:${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleAnswerSubmit = async (answer: string) => {
    if (isSubmitting) return

    setIsSubmitting(true)
    try {
      const result = await submitContestAnswer({
        userId,
        contestId: contest.id,
        questionId: currentQuestion.id,
        answer,
        questionIndex: currentIndex,
      })

      setResults((prev) => ({
        ...prev,
        [currentIndex]: result,
      }))

      setAnswers((prev) => ({ ...prev, [currentIndex]: answer }))
    } catch (error) {
      console.error("Error submitting answer:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleAutoSubmit = useCallback(async () => {
    await handleFinalSubmit()
  }, [answers, contestStartTime, tabSwitchCount])

  const handleFinalSubmit = async () => {
    setIsSubmitting(true)
    try {
      const totalTime = Math.floor((Date.now() - contestStartTime) / 1000)
      const correctAnswers = Object.values(results).filter((r) => r.correct).length
      const wrongAnswers = Object.values(results).filter((r) => !r.correct).length
      const unanswered = questions.length - Object.keys(answers).length

      // Calculate score (can be customized based on contest rules)
      let score = correctAnswers * 100
      if (contest.rules?.negative_marking) {
        score -= wrongAnswers * (contest.rules.negative_marking * 100)
      }

      await submitContestResult({
        userId,
        contestId: contest.id,
        score: Math.max(0, score),
        totalTime,
        correctAnswers,
        wrongAnswers,
        unanswered,
        tabSwitchCount,
      })

      router.push(`/contest/${contest.id}/results`)
    } catch (error) {
      console.error("Error submitting contest:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const getTimeColor = () => {
    if (timeLeft > 1800) return "text-green-600" // > 30 min
    if (timeLeft > 600) return "text-yellow-600" // > 10 min
    return "text-red-600" // < 10 min
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Contest Header */}
      <div className="bg-gray-800 border-b border-gray-700 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Trophy className="h-6 w-6 text-yellow-500" />
              <div>
                <h1 className="text-xl font-bold">{contest.title}</h1>
                <p className="text-sm text-gray-400">
                  Question {currentIndex + 1} of {questions.length} • {answeredCount} answered
                </p>
              </div>
            </div>

            <div className="flex items-center gap-6">
              {/* Tab switch warning */}
              {tabSwitchCount > 0 && (
                <div className="flex items-center gap-2 text-orange-400">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="text-sm">Tab switches: {tabSwitchCount}</span>
                </div>
              )}

              {/* Full screen indicator */}
              {contest.rules?.full_screen_required && (
                <div className="flex items-center gap-2">
                  {isFullScreen ? (
                    <Eye className="h-4 w-4 text-green-400" />
                  ) : (
                    <EyeOff className="h-4 w-4 text-red-400" />
                  )}
                  <span className="text-sm">{isFullScreen ? "Full Screen" : "Exit Full Screen"}</span>
                </div>
              )}

              {/* Timer */}
              <div className="flex items-center gap-2">
                <Clock className={`h-5 w-5 ${getTimeColor()}`} />
                <span className={`font-mono text-xl font-bold ${getTimeColor()}`}>{formatTime(timeLeft)}</span>
              </div>

              <Button
                onClick={() => setShowSubmitDialog(true)}
                variant="outline"
                className="border-green-600 text-green-400 hover:bg-green-600 hover:text-white"
              >
                <Send className="mr-2 h-4 w-4" />
                Submit Contest
              </Button>
            </div>
          </div>

          <div className="mt-4">
            <Progress value={progress} className="h-2" />
          </div>
        </div>
      </div>

      {/* Warnings */}
      {!isFullScreen && contest.rules?.full_screen_required && (
        <Alert className="m-4 border-red-600 bg-red-900/20">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription className="text-red-400">
            This contest requires full-screen mode. Please press F11 or click the full-screen button.
          </AlertDescription>
        </Alert>
      )}

      {tabSwitchCount > 3 && (
        <Alert className="m-4 border-orange-600 bg-orange-900/20">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription className="text-orange-400">
            Multiple tab switches detected. This may affect your contest standing.
          </AlertDescription>
        </Alert>
      )}

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">{currentQuestion.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <QuestionRenderer
                    question={currentQuestion}
                    onSubmit={handleAnswerSubmit}
                    isSubmitting={isSubmitting}
                    showExplanation={false}
                    userAnswer={answers[currentIndex]}
                    result={results[currentIndex]}
                  />
                </CardContent>
              </Card>
            </motion.div>
          </AnimatePresence>

          {/* Question Navigation */}
          <div className="mt-8">
            <div className="grid grid-cols-10 gap-2 max-w-2xl mx-auto">
              {questions.map((_, index) => (
                <Button
                  key={index}
                  variant={index === currentIndex ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentIndex(index)}
                  className={`aspect-square ${
                    answers[index]
                      ? "bg-green-600 hover:bg-green-700 border-green-600"
                      : index === currentIndex
                        ? "bg-blue-600 hover:bg-blue-700"
                        : "border-gray-600 hover:bg-gray-700"
                  }`}
                >
                  {index + 1}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Submit Dialog */}
      <Dialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Submit Contest</DialogTitle>
            <DialogDescription className="text-gray-400">
              Are you sure you want to submit your contest? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-green-400">{answeredCount}</p>
                <p className="text-sm text-gray-400">Answered</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-400">{questions.length - answeredCount}</p>
                <p className="text-sm text-gray-400">Unanswered</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-blue-400">{formatTime(timeLeft)}</p>
                <p className="text-sm text-gray-400">Time Left</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowSubmitDialog(false)}
                className="flex-1 border-gray-600 hover:bg-gray-700"
              >
                Continue Contest
              </Button>
              <Button
                onClick={handleFinalSubmit}
                disabled={isSubmitting}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                {isSubmitting ? "Submitting..." : "Submit Contest"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
