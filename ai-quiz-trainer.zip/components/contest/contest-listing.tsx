"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, Calendar, Clock, Users, Star, Play, CheckCircle, AlertCircle } from "lucide-react"
import Link from "next/link"
import { registerForContest } from "@/lib/services/contest-service"
import { toast } from "@/hooks/use-toast"

interface ContestListingProps {
  upcomingContests: any[]
  pastContests: any[]
  registeredContestIds: string[]
  userResults: any[]
  userId: string
}

export default function ContestListing({
  upcomingContests,
  pastContests,
  registeredContestIds,
  userResults,
  userId,
}: ContestListingProps) {
  const [registering, setRegistering] = useState<string | null>(null)
  const [registered, setRegistered] = useState<string[]>(registeredContestIds)

  const handleRegister = async (contestId: string) => {
    setRegistering(contestId)
    try {
      await registerForContest(userId, contestId)
      setRegistered((prev) => [...prev, contestId])
      toast({
        title: "Registration Successful!",
        description: "You've been registered for the contest. Good luck!",
      })
    } catch (error) {
      toast({
        title: "Registration Failed",
        description: "Unable to register for the contest. Please try again.",
        variant: "destructive",
      })
    } finally {
      setRegistering(null)
    }
  }

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString)
    return {
      date: date.toLocaleDateString("en-IN", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      }),
      time: date.toLocaleTimeString("en-IN", {
        hour: "2-digit",
        minute: "2-digit",
        timeZone: "Asia/Kolkata",
      }),
    }
  }

  const getContestStatus = (contest: any) => {
    const now = new Date()
    const startTime = new Date(contest.start_time)
    const endTime = new Date(contest.end_time)
    const registrationCutoff = new Date(contest.registration_cutoff)

    if (now < registrationCutoff) {
      return { status: "upcoming", label: "Registration Open", color: "bg-green-500" }
    } else if (now < startTime) {
      return { status: "registration_closed", label: "Registration Closed", color: "bg-yellow-500" }
    } else if (now < endTime) {
      return { status: "live", label: "Live Now", color: "bg-red-500" }
    } else {
      return { status: "ended", label: "Ended", color: "bg-gray-500" }
    }
  }

  const getTimeUntilContest = (startTime: string) => {
    const now = new Date()
    const start = new Date(startTime)
    const diff = start.getTime() - now.getTime()

    if (diff <= 0) return "Started"

    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

    if (days > 0) return `${days}d ${hours}h`
    if (hours > 0) return `${hours}h ${minutes}m`
    return `${minutes}m`
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <div className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="p-4 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full">
                <Trophy className="h-10 w-10 text-white" />
              </div>
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">
              Programming Contests
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Compete with developers across India every Sunday at 7:00 PM IST. Test your skills and climb the
              leaderboard!
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="upcoming" className="space-y-8">
          <TabsList className="grid w-full grid-cols-3 max-w-md mx-auto">
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="past">Past Contests</TabsTrigger>
            <TabsTrigger value="results">My Results</TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming" className="space-y-6">
            {upcomingContests.length > 0 ? (
              <div className="grid gap-6 max-w-4xl mx-auto">
                {upcomingContests.map((contest) => {
                  const status = getContestStatus(contest)
                  const startDateTime = formatDateTime(contest.start_time)
                  const endDateTime = formatDateTime(contest.end_time)
                  const isRegistered = registered.includes(contest.id)
                  const canRegister = status.status === "upcoming" && !isRegistered
                  const canJoin = status.status === "live" && isRegistered

                  return (
                    <Card
                      key={contest.id}
                      className="shadow-xl border-0 bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm"
                    >
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="space-y-2">
                            <CardTitle className="text-2xl text-gray-900 dark:text-gray-100">{contest.title}</CardTitle>
                            <CardDescription className="text-base">
                              {contest.description || "Weekly programming contest with challenging problems"}
                            </CardDescription>
                          </div>
                          <Badge className={`${status.color} text-white border-0 px-3 py-1`}>{status.label}</Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="flex items-center gap-3">
                            <Calendar className="h-5 w-5 text-blue-600" />
                            <div>
                              <p className="font-medium text-gray-900 dark:text-gray-100">{startDateTime.date}</p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">Contest Date</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <Clock className="h-5 w-5 text-green-600" />
                            <div>
                              <p className="font-medium text-gray-900 dark:text-gray-100">
                                {startDateTime.time} - {endDateTime.time}
                              </p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">Duration: 90 minutes</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <Users className="h-5 w-5 text-purple-600" />
                            <div>
                              <p className="font-medium text-gray-900 dark:text-gray-100">
                                {contest.max_participants || "Unlimited"}
                              </p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">Max Participants</p>
                            </div>
                          </div>
                        </div>

                        {status.status === "upcoming" && (
                          <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-blue-900 dark:text-blue-100">
                                  Contest starts in: {getTimeUntilContest(contest.start_time)}
                                </p>
                                <p className="text-sm text-blue-700 dark:text-blue-300">
                                  Registration closes 10 minutes before start
                                </p>
                              </div>
                            </div>
                          </div>
                        )}

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            {isRegistered && (
                              <div className="flex items-center gap-2 text-green-600">
                                <CheckCircle className="h-5 w-5" />
                                <span className="font-medium">Registered</span>
                              </div>
                            )}
                            {contest.rules?.full_screen_required && (
                              <div className="flex items-center gap-2 text-orange-600">
                                <AlertCircle className="h-4 w-4" />
                                <span className="text-sm">Full-screen required</span>
                              </div>
                            )}
                          </div>

                          <div className="flex gap-3">
                            {canRegister && (
                              <Button
                                onClick={() => handleRegister(contest.id)}
                                disabled={registering === contest.id}
                                className="bg-green-600 hover:bg-green-700 text-white"
                              >
                                {registering === contest.id ? "Registering..." : "Register"}
                              </Button>
                            )}
                            {canJoin && (
                              <Link href={`/contest/${contest.id}/live`}>
                                <Button className="bg-red-600 hover:bg-red-700 text-white">
                                  <Play className="mr-2 h-4 w-4" />
                                  Join Contest
                                </Button>
                              </Link>
                            )}
                            {status.status === "ended" && (
                              <Link href={`/contest/${contest.id}/results`}>
                                <Button variant="outline">View Results</Button>
                              </Link>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            ) : (
              <Card className="max-w-md mx-auto text-center py-12">
                <CardContent>
                  <Trophy className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No Upcoming Contests</h3>
                  <p className="text-gray-600 dark:text-gray-400">Check back soon for new contests!</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="past" className="space-y-6">
            {pastContests.length > 0 ? (
              <div className="grid gap-4 max-w-4xl mx-auto">
                {pastContests.map((contest) => {
                  const startDateTime = formatDateTime(contest.start_time)

                  return (
                    <Card
                      key={contest.id}
                      className="shadow-lg border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm"
                    >
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">{contest.title}</h3>
                            <p className="text-gray-600 dark:text-gray-400">
                              {startDateTime.date} at {startDateTime.time}
                            </p>
                          </div>
                          <Link href={`/contest/${contest.id}/results`}>
                            <Button variant="outline">View Results</Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            ) : (
              <Card className="max-w-md mx-auto text-center py-12">
                <CardContent>
                  <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No Past Contests</h3>
                  <p className="text-gray-600 dark:text-gray-400">Past contests will appear here</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            {userResults.length > 0 ? (
              <div className="grid gap-4 max-w-4xl mx-auto">
                {userResults.map((result) => (
                  <Card key={result.id} className="shadow-lg border-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="space-y-2">
                          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                            {result.contests?.title}
                          </h3>
                          <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                            <span>Score: {result.score}</span>
                            <span>Rank: #{result.rank_national || "N/A"}</span>
                            <span>
                              Rating: {result.rating_after} ({result.rating_delta > 0 ? "+" : ""}
                              {result.rating_delta})
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Star className="h-5 w-5 text-yellow-500" />
                          <span className="font-semibold text-gray-900 dark:text-gray-100">{result.rating_after}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="max-w-md mx-auto text-center py-12">
                <CardContent>
                  <Star className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No Contest Results</h3>
                  <p className="text-gray-600 dark:text-gray-400">Participate in contests to see your results here</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
