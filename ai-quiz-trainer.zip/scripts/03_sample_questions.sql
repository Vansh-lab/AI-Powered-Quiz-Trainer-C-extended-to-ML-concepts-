-- Sample questions for AI Quiz Trainer
-- This includes a variety of question types across different languages and DSA topics

-- C Programming Questions
INSERT INTO questions (type, title, text, language_tags, difficulty, skills, options, correct_answer, explanation_md, code_snippets, time_limit) VALUES

-- C - Basic Pointers
('mcq', 'Pointer Basics', 
'What will be the output of the following C code?

```c
#include <stdio.h>
int main() {
    int x = 10;
    int *p = &x;
    printf("%d", *p);
    return 0;
}
```', 
ARRAY['C', 'DSA/Pointers'], 2, ARRAY['pointers', 'basic_syntax'],
'[{"id": "a", "text": "10"}, {"id": "b", "text": "Address of x"}, {"id": "c", "text": "Garbage value"}, {"id": "d", "text": "Compilation error"}]',
'a',
'The pointer `p` stores the address of variable `x`. When we dereference `p` using `*p`, we get the value stored at that address, which is 10.',
'[{"lang": "c", "code": "#include <stdio.h>\nint main() {\n    int x = 10;\n    int *p = &x;\n    printf(\"%d\", *p); // Prints 10\n    return 0;\n}", "title": "Complete Code"}]',
45),

-- C - Array Indexing
('code_output', 'Array Bounds', 
'Predict the output of this C program:

```c
#include <stdio.h>
int main() {
    int arr[5] = {1, 2, 3, 4, 5};
    printf("%d %d", arr[0], arr[4]);
    return 0;
}
```',
ARRAY['C', 'DSA/Arrays'], 1, ARRAY['arrays', 'indexing'],
NULL,
'1 5',
'Array indexing in C starts from 0. `arr[0]` gives the first element (1) and `arr[4]` gives the fifth element (5).',
'[{"lang": "c", "code": "int arr[5] = {1, 2, 3, 4, 5};\n// arr[0] = 1, arr[1] = 2, ..., arr[4] = 5", "title": "Array Layout"}]',
30),

-- Java - Object Oriented
('mcq', 'Java Inheritance',
'Which of the following is true about method overriding in Java?',
ARRAY['Java', 'OOP'], 3, ARRAY['inheritance', 'polymorphism'],
'[{"id": "a", "text": "Private methods can be overridden"}, {"id": "b", "text": "Static methods can be overridden"}, {"id": "c", "text": "Final methods can be overridden"}, {"id": "d", "text": "Protected methods can be overridden"}]',
'd',
'Protected methods can be overridden in subclasses. Private methods are not inherited, static methods are hidden (not overridden), and final methods cannot be overridden.',
'[{"lang": "java", "code": "class Parent {\n    protected void method() { }\n}\nclass Child extends Parent {\n    @Override\n    protected void method() { } // Valid override\n}", "title": "Method Override Example"}]',
60),

-- Python - Data Structures
('fill_in', 'Python List Comprehension',
'Complete the Python list comprehension to create a list of squares of even numbers from 1 to 10:

```python
squares = [_____ for x in range(1, 11) if _____]
```',
ARRAY['Python', 'DSA/Arrays'], 2, ARRAY['list_comprehension', 'conditionals'],
NULL,
'x**2, x % 2 == 0',
'List comprehensions follow the pattern `[expression for item in iterable if condition]`. Here we want `x**2` (square) for numbers where `x % 2 == 0` (even).',
'[{"lang": "python", "code": "squares = [x**2 for x in range(1, 11) if x % 2 == 0]\nprint(squares)  # [4, 16, 36, 64, 100]", "title": "Complete Solution"}]',
45),

-- DSA - Binary Search
('mcq', 'Binary Search Complexity',
'What is the time complexity of binary search on a sorted array of n elements?',
ARRAY['DSA/Searching', 'Algorithms'], 2, ARRAY['time_complexity', 'binary_search'],
'[{"id": "a", "text": "O(n)"}, {"id": "b", "text": "O(log n)"}, {"id": "c", "text": "O(n log n)"}, {"id": "d", "text": "O(1)"}]',
'b',
'Binary search divides the search space in half with each comparison, leading to O(log n) time complexity.',
'[{"lang": "python", "code": "def binary_search(arr, target):\n    left, right = 0, len(arr) - 1\n    while left <= right:\n        mid = (left + right) // 2\n        if arr[mid] == target:\n            return mid\n        elif arr[mid] < target:\n            left = mid + 1\n        else:\n            right = mid - 1\n    return -1", "title": "Binary Search Implementation"}]',
40),

-- JavaScript - Async Programming
('bug_fix', 'JavaScript Promise Bug',
'Fix the bug in this JavaScript async function:

```javascript
async function fetchData() {
    const response = fetch("https://api.example.com/data");
    const data = response.json();
    return data;
}
```',
ARRAY['JavaScript', 'Async'], 3, ARRAY['promises', 'async_await'],
NULL,
'await fetch, await response.json()',
'Both `fetch()` and `response.json()` return promises and need to be awaited in an async function.',
'[{"lang": "javascript", "code": "async function fetchData() {\n    const response = await fetch(\"https://api.example.com/data\");\n    const data = await response.json();\n    return data;\n}", "title": "Corrected Code"}]',
50);

-- Update question metrics (this would normally be done by the application)
UPDATE questions SET metrics = '{"avg_time": 35, "correct_rate": 0.75, "attempt_count": 100}' WHERE language_tags && ARRAY['C'];
UPDATE questions SET metrics = '{"avg_time": 45, "correct_rate": 0.68, "attempt_count": 80}' WHERE language_tags && ARRAY['Java'];
UPDATE questions SET metrics = '{"avg_time": 40, "correct_rate": 0.72, "attempt_count": 90}' WHERE language_tags && ARRAY['Python'];
UPDATE questions SET metrics = '{"avg_time": 50, "correct_rate": 0.65, "attempt_count": 70}' WHERE language_tags && ARRAY['JavaScript'];
