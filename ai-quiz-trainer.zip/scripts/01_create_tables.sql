-- AI Quiz Trainer Database Schema
-- Create core tables for the quiz platform

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table with profile information
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    handle VARCHAR(50) UNIQUE NOT NULL,
    avatar_url TEXT,
    college VARCHAR(255),
    company VARCHAR(255),
    state VARCHAR(100),
    city VARCHAR(100),
    rating INTEGER DEFAULT 1200,
    roles TEXT[] DEFAULT ARRAY['user'],
    preferences JSONB DEFAULT '{"theme": "system", "dyslexia_friendly": false}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Questions table with rich metadata
CREATE TABLE questions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type VARCHAR(20) NOT NULL CHECK (type IN ('mcq', 'code_output', 'bug_fix', 'fill_in', 'coding_snippet')),
    title VARCHAR(500) NOT NULL,
    text TEXT NOT NULL, -- Rich markdown content
    language_tags TEXT[] NOT NULL, -- ['C', 'DSA/Arrays', etc.]
    difficulty INTEGER NOT NULL CHECK (difficulty BETWEEN 1 AND 5),
    skills TEXT[] DEFAULT ARRAY[]::TEXT[], -- ['pointers', 'recursion', etc.]
    options JSONB, -- For MCQ questions: [{"id": "a", "text": "Option A"}, ...]
    correct_answer TEXT NOT NULL,
    explanation_md TEXT NOT NULL,
    code_snippets JSONB DEFAULT '[]', -- [{"lang": "c", "code": "...", "title": "Example"}]
    constraints JSONB DEFAULT '{}', -- Time limits, memory limits, etc.
    time_limit INTEGER DEFAULT 60, -- seconds
    author_id UUID REFERENCES users(id),
    review_flags INTEGER DEFAULT 0,
    metrics JSONB DEFAULT '{"avg_time": 0, "correct_rate": 0, "attempt_count": 0}',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User attempts tracking
CREATE TABLE attempts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    question_id UUID NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
    is_correct BOOLEAN NOT NULL,
    user_answer TEXT NOT NULL,
    time_taken INTEGER NOT NULL, -- seconds
    difficulty_at_time INTEGER NOT NULL, -- Question difficulty when attempted
    user_ability_before DECIMAL(10,4), -- User's theta before this attempt
    user_ability_after DECIMAL(10,4), -- User's theta after this attempt
    context JSONB DEFAULT '{}', -- Contest, practice mode, etc.
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Spaced repetition review cards
CREATE TABLE review_cards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    question_id UUID NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
    easiness DECIMAL(4,2) DEFAULT 2.5,
    interval_days INTEGER DEFAULT 1,
    repetitions INTEGER DEFAULT 0,
    due_date DATE NOT NULL DEFAULT CURRENT_DATE,
    last_reviewed TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, question_id)
);

-- Contests table
CREATE TABLE contests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE NOT NULL,
    registration_cutoff TIMESTAMP WITH TIME ZONE NOT NULL,
    rules JSONB DEFAULT '{"negative_marking": 0.25, "full_screen_required": true}',
    question_ids UUID[] NOT NULL,
    max_participants INTEGER,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Contest registrations
CREATE TABLE contest_registrations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contest_id UUID NOT NULL REFERENCES contests(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    registered_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(contest_id, user_id)
);

-- Contest results
CREATE TABLE contest_results (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contest_id UUID NOT NULL REFERENCES contests(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score INTEGER NOT NULL DEFAULT 0,
    total_time INTEGER NOT NULL DEFAULT 0, -- seconds
    correct_answers INTEGER DEFAULT 0,
    wrong_answers INTEGER DEFAULT 0,
    unanswered INTEGER DEFAULT 0,
    rank_national INTEGER,
    rank_state INTEGER,
    rank_college INTEGER,
    rating_before INTEGER NOT NULL,
    rating_after INTEGER NOT NULL,
    rating_delta INTEGER NOT NULL,
    submitted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(contest_id, user_id)
);

-- User statistics and progress tracking
CREATE TABLE user_stats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    language_tag VARCHAR(50) NOT NULL,
    total_attempts INTEGER DEFAULT 0,
    correct_attempts INTEGER DEFAULT 0,
    accuracy DECIMAL(5,4) DEFAULT 0,
    avg_time_per_question DECIMAL(8,2) DEFAULT 0,
    mastery_score DECIMAL(5,4) DEFAULT 0,
    current_streak INTEGER DEFAULT 0,
    best_streak INTEGER DEFAULT 0,
    last_activity TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, language_tag)
);

-- Badges and achievements
CREATE TABLE badges (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT NOT NULL,
    icon VARCHAR(100),
    criteria JSONB NOT NULL, -- Conditions for earning the badge
    rarity VARCHAR(20) DEFAULT 'common' CHECK (rarity IN ('common', 'rare', 'epic', 'legendary')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User badges (earned achievements)
CREATE TABLE user_badges (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    badge_id UUID NOT NULL REFERENCES badges(id) ON DELETE CASCADE,
    earned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, badge_id)
);

-- Create indexes for better performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_handle ON users(handle);
CREATE INDEX idx_users_rating ON users(rating DESC);
CREATE INDEX idx_users_state ON users(state);

CREATE INDEX idx_questions_language_tags ON questions USING GIN(language_tags);
CREATE INDEX idx_questions_difficulty ON questions(difficulty);
CREATE INDEX idx_questions_active ON questions(is_active);

CREATE INDEX idx_attempts_user_id ON attempts(user_id);
CREATE INDEX idx_attempts_question_id ON attempts(question_id);
CREATE INDEX idx_attempts_created_at ON attempts(created_at DESC);

CREATE INDEX idx_review_cards_user_due ON review_cards(user_id, due_date);
CREATE INDEX idx_review_cards_due_date ON review_cards(due_date);

CREATE INDEX idx_contests_start_time ON contests(start_time);
CREATE INDEX idx_contests_active ON contests(is_active);

CREATE INDEX idx_contest_results_contest_score ON contest_results(contest_id, score DESC);
CREATE INDEX idx_contest_results_user ON contest_results(user_id);

CREATE INDEX idx_user_stats_user_lang ON user_stats(user_id, language_tag);
