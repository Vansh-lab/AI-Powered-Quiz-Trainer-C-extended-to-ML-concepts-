-- Seed initial data for AI Quiz Trainer

-- Insert initial badges
INSERT INTO badges (name, description, icon, criteria, rarity) VALUES
('First Steps', 'Complete your first quiz question', 'trophy', '{"type": "attempts", "count": 1}', 'common'),
('Quick Learner', 'Answer 10 questions correctly', 'zap', '{"type": "correct_answers", "count": 10}', 'common'),
('Week Warrior', 'Maintain a 7-day streak', 'calendar', '{"type": "streak", "days": 7}', 'rare'),
('C Master', 'Achieve 80% accuracy in C programming', 'code', '{"type": "language_accuracy", "language": "C", "accuracy": 0.8}', 'rare'),
('DSA Expert', 'Master all DSA topics with 90% accuracy', 'brain', '{"type": "topic_mastery", "topics": ["DSA"], "accuracy": 0.9}', 'epic'),
('Contest Champion', 'Win a weekly contest', 'crown', '{"type": "contest_rank", "rank": 1}', 'legendary'),
('State Topper', 'Reach top 10 in your state', 'map-pin', '{"type": "state_rank", "rank": 10}', 'epic'),
('Speed Demon', 'Answer 50 questions in under 30 seconds each', 'timer', '{"type": "speed", "count": 50, "max_time": 30}', 'rare');

-- Insert sample programming languages and DSA topics for questions
-- This will be expanded with actual questions in the next script
